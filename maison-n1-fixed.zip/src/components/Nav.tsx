import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLang } from '@/i18n/LanguageContext';

export function Nav() {
  const { pathname } = useLocation();
  const { t } = useLang();
  const [hovered, setHovered] = useState<string | null>(null);

  const LINKS = [
    { to: '/', label: t.nav.home, num: '01' },
    { to: '/gallery', label: t.nav.gallery, num: '02' },
  ];

  return (
    <>
      {/* Desktop top nav — tiny, editorial */}
      <nav className="fixed top-0 left-1/2 -translate-x-1/2 z-[60] hidden md:flex items-center gap-10 pt-5">
        {LINKS.map((l) => {
          const active = pathname === l.to;
          return (
            <Link
              key={l.to}
              to={l.to}
              className="group relative font-mono text-[0.62rem] tracking-[0.28em] uppercase no-underline"
              style={{
                color: active ? 'var(--color-graphite-900)' : 'var(--color-graphite-500)',
                mixBlendMode: 'difference',
                transition: 'letter-spacing 0.5s cubic-bezier(0.22,1,0.36,1), color 0.4s',
                letterSpacing: hovered === l.to ? '0.36em' : '0.28em',
              }}
              onMouseEnter={() => setHovered(l.to)}
              onMouseLeave={() => setHovered(null)}
            >
              <span className="relative">
                {l.label}
                <span
                  className="absolute -bottom-1.5 left-0 h-px bg-current transition-all duration-500"
                  style={{ width: active ? '100%' : hovered === l.to ? '100%' : '0%' }}
                />
              </span>
            </Link>
          );
        })}
      </nav>

      {/* Mobile floating island */}
      <nav
        className="fixed left-1/2 -translate-x-1/2 z-[60] md:hidden flex items-center gap-4 px-5 py-2.5 rounded-full"
        style={{
          bottom: 'calc(1.25rem + env(safe-area-inset-bottom))',
          background: 'rgba(14,14,16,0.55)',
          backdropFilter: 'blur(14px)',
          WebkitBackdropFilter: 'blur(14px)',
          border: '1px solid rgba(255,255,255,0.08)',
        }}
      >
        {LINKS.map((l) => {
          const active = pathname === l.to;
          return (
            <Link
              key={l.to}
              to={l.to}
              className="flex items-center gap-1.5 font-mono text-[0.55rem] tracking-[0.2em] uppercase no-underline"
              style={{
                color: active ? '#fff' : 'rgba(255,255,255,0.45)',
                transition: 'color 0.3s',
              }}
            >
              <span style={{ color: active ? 'var(--color-accent)' : 'rgba(255,255,255,0.3)' }}>
                {l.num}
              </span>
              {l.label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
