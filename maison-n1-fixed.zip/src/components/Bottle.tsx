export function Bottle({ className = '' }: { className?: string }) {
  return (
    <svg
      className={`bottle-svg ${className}`}
      viewBox="0 0 300 620"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Perfume flacon"
      role="img"
    >
      <defs>
        {/* Main glass body — vertical gradient with depth */}
        <linearGradient id="glass" x1="60" y1="0" x2="240" y2="620" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#f4f4f5" stopOpacity="0.95" />
          <stop offset="0.12" stopColor="#e8e8ea" stopOpacity="0.88" />
          <stop offset="0.35" stopColor="#b8b8be" stopOpacity="0.78" />
          <stop offset="0.55" stopColor="#7a7a82" stopOpacity="0.82" />
          <stop offset="0.82" stopColor="#3a3a42" stopOpacity="0.88" />
          <stop offset="1" stopColor="#1a1a1e" stopOpacity="0.92" />
        </linearGradient>

        {/* Edge highlight — left side bright, right side dark for 3D cylinder feel */}
        <linearGradient id="edge" x1="0" y1="0" x2="300" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.92" />
          <stop offset="0.08" stopColor="#ffffff" stopOpacity="0.45" />
          <stop offset="0.2" stopColor="#ffffff" stopOpacity="0.05" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.8" stopColor="#000000" stopOpacity="0.15" />
          <stop offset="0.95" stopColor="#000000" stopOpacity="0.5" />
          <stop offset="1" stopColor="#000000" stopOpacity="0.65" />
        </linearGradient>

        {/* Cap — brushed metal gradient */}
        <linearGradient id="cap" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a4a52" />
          <stop offset="0.15" stopColor="#2a2a30" />
          <stop offset="0.5" stopColor="#121214" />
          <stop offset="0.85" stopColor="#08080a" />
          <stop offset="1" stopColor="#050506" />
        </linearGradient>

        {/* Cap side highlight — metallic sheen */}
        <linearGradient id="capSheen" x1="0" y1="0" x2="300" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.12" stopColor="#ffffff" stopOpacity="0.35" />
          <stop offset="0.2" stopColor="#ffffff" stopOpacity="0.08" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.85" stopColor="#000000" stopOpacity="0.3" />
          <stop offset="1" stopColor="#000000" stopOpacity="0.5" />
        </linearGradient>

        {/* Liquid — warm amber with depth */}
        <linearGradient id="liquid" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#d9c8a8" stopOpacity="0.5" />
          <stop offset="0.3" stopColor="#c9b89a" stopOpacity="0.6" />
          <stop offset="1" stopColor="#6a5a3e" stopOpacity="0.78" />
        </linearGradient>

        {/* Liquid edge — subtle glass-liquid interface */}
        <linearGradient id="liquidEdge" x1="0" y1="0" x2="300" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.25" />
          <stop offset="0.15" stopColor="#ffffff" stopOpacity="0.05" />
          <stop offset="0.85" stopColor="#000000" stopOpacity="0.15" />
          <stop offset="1" stopColor="#000000" stopOpacity="0.35" />
        </linearGradient>

        {/* Soft sheen — top-left light source */}
        <radialGradient id="sheen" cx="0.28" cy="0.22" r="0.55">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.65" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0.12" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>

        {/* Secondary highlight — right edge subtle bounce light */}
        <radialGradient id="sheen2" cx="0.82" cy="0.55" r="0.3">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.18" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>

        {/* Inner shadow at bottom for depth */}
        <linearGradient id="bottomShadow" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#000000" stopOpacity="0.5" />
          <stop offset="0.15" stopColor="#000000" stopOpacity="0.1" />
          <stop offset="1" stopColor="#000000" stopOpacity="0" />
        </linearGradient>

        {/* Glass blur filter for soft reflections */}
        <filter id="glassBlur" x="-5%" y="-5%" width="110%" height="110%">
          <feGaussianBlur stdDeviation="1.5" />
        </filter>
      </defs>

      {/* shadow under bottle */}
      <ellipse cx="150" cy="608" rx="95" ry="12" fill="black" opacity="0.45" filter="url(#glassBlur)" />

      {/* CAP — metallic, with depth */}
      {/* cap top edge */}
      <rect x="116" y="0" width="68" height="6" rx="2" fill="#3a3a40" />
      <rect x="116" y="0" width="68" height="6" rx="2" fill="url(#capSheen)" opacity="0.5" />
      {/* cap body */}
      <rect x="118" y="4" width="64" height="82" rx="3" fill="url(#cap)" />
      <rect x="118" y="4" width="64" height="82" rx="3" fill="url(#capSheen)" opacity="0.6" />
      {/* cap top highlight strip */}
      <rect x="124" y="8" width="5" height="74" rx="2.5" fill="#ffffff" opacity="0.22" filter="url(#glassBlur)" />
      {/* cap second highlight — thinner, offset */}
      <rect x="132" y="8" width="2" height="74" rx="1" fill="#ffffff" opacity="0.12" />
      {/* cap bottom rim */}
      <rect x="118" y="82" width="64" height="5" rx="1" fill="#08080a" />
      <rect x="118" y="82" width="64" height="2" rx="1" fill="#1a1a1e" opacity="0.6" />

      {/* NECK — glass, slightly darker than body */}
      <rect x="128" y="86" width="44" height="22" fill="url(#glass)" />
      <rect x="128" y="86" width="44" height="22" fill="url(#edge)" opacity="0.25" />
      {/* neck highlight */}
      <rect x="131" y="88" width="3" height="18" rx="1.5" fill="#ffffff" opacity="0.2" filter="url(#glassBlur)" />

      {/* BODY — main glass form */}
      <path
        d="M62 130 Q62 106 86 106 L214 106 Q238 106 238 130 L238 560 Q238 596 202 596 L98 596 Q62 596 62 560 Z"
        fill="url(#glass)"
      />
      {/* edge shading for 3D cylinder illusion */}
      <path
        d="M62 130 Q62 106 86 106 L214 106 Q238 106 238 130 L238 560 Q238 596 202 596 L98 596 Q62 596 62 560 Z"
        fill="url(#edge)"
        opacity="0.3"
      />

      {/* LIQUID — with meniscus curve */}
      <path
        d="M74 295 Q150 285 226 295 L226 556 Q226 584 198 584 L102 584 Q74 584 74 556 Z"
        fill="url(#liquid)"
      />
      {/* liquid edge for glass-liquid interface */}
      <path
        d="M74 295 Q150 285 226 295 L226 556 Q226 584 198 584 L102 584 Q74 584 74 556 Z"
        fill="url(#liquidEdge)"
        opacity="0.3"
      />
      {/* liquid surface highlight — meniscus */}
      <path
        d="M74 295 Q150 285 226 295"
        stroke="#ffffff"
        strokeWidth="1.2"
        strokeOpacity="0.25"
        fill="none"
      />

      {/* GLASS SHEEN — primary light from top-left */}
      <path
        d="M62 130 Q62 106 86 106 L214 106 Q238 106 238 130 L238 560 Q238 596 202 596 L98 596 Q62 596 62 560 Z"
        fill="url(#sheen)"
        opacity="0.55"
      />
      {/* secondary bounce light */}
      <path
        d="M62 130 Q62 106 86 106 L214 106 Q238 106 238 130 L238 560 Q238 596 202 596 L98 596 Q62 596 62 560 Z"
        fill="url(#sheen2)"
        opacity="0.4"
      />

      {/* Left edge bright highlight — sharp glass reflection */}
      <rect x="68" y="140" width="3" height="400" rx="1.5" fill="#ffffff" opacity="0.28" filter="url(#glassBlur)" />
      {/* Right edge subtle dark reflection */}
      <rect x="228" y="140" width="3" height="400" rx="1.5" fill="#000000" opacity="0.2" filter="url(#glassBlur)" />

      {/* Bottom inner shadow for depth */}
      <path
        d="M62 130 Q62 106 86 106 L214 106 Q238 106 238 130 L238 560 Q238 596 202 596 L98 596 Q62 596 62 560 Z"
        fill="url(#bottomShadow)"
        opacity="0.5"
      />

      {/* center etched line */}
      <line x1="150" y1="120" x2="150" y2="586" stroke="#ffffff" strokeOpacity="0.1" strokeWidth="0.8" />

      {/* LABEL PLATE — subtle, embedded */}
      <rect x="104" y="340" width="92" height="120" rx="1" fill="#0a0a0c" opacity="0.32" />
      <rect x="104" y="340" width="92" height="120" rx="1" fill="url(#edge)" opacity="0.08" />
      <text
        x="150" y="392"
        textAnchor="middle"
        fontFamily="'Space Grotesk', sans-serif"
        fontSize="13"
        letterSpacing="3"
        fill="#e8e6df"
        opacity="0.85"
      >
        N° I
      </text>
      <line x1="120" y1="406" x2="180" y2="406" stroke="#e8e6df" strokeOpacity="0.4" strokeWidth="0.5" />
      <text
        x="150" y="432"
        textAnchor="middle"
        fontFamily="'JetBrains Mono', monospace"
        fontSize="6"
        letterSpacing="2"
        fill="#c9b89a"
        opacity="0.75"
      >
        EAU DE PARFUM
      </text>
      <text
        x="150" y="448"
        textAnchor="middle"
        fontFamily="'JetBrains Mono', monospace"
        fontSize="5"
        letterSpacing="1.5"
        fill="#8a8a92"
        opacity="0.6"
      >
        100 ML / 3.4 FL OZ
      </text>
    </svg>
  );
}
