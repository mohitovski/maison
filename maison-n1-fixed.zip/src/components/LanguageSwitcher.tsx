import { useLang } from '@/i18n/LanguageContext';
import { type Lang } from '@/i18n/translations';

export function LanguageSwitcher() {
  const { lang, setLang, t } = useLang();

  return (
    <div
      className="fixed top-[calc(1.25rem+env(safe-area-inset-top))] right-5 md:top-auto md:bottom-7 md:right-8 z-[60] flex items-center gap-2 font-mono select-none"
      style={{
        fontSize: '0.55rem',
        letterSpacing: '0.2em',
        mixBlendMode: 'difference',
      }}
    >
      {(['ru', 'en'] as Lang[]).map((l, i) => (
        <span key={l} className="flex items-center gap-2">
          {i > 0 && (
            <span style={{ color: 'rgba(255,255,255,0.3)' }}>/</span>
          )}
          <button
            onClick={() => setLang(l)}
            className="transition-colors duration-300 uppercase"
            style={{
              color: lang === l ? '#fff' : 'rgba(255,255,255,0.4)',
              cursor: 'pointer',
              background: 'none',
              border: 'none',
              padding: 0,
              fontFamily: 'inherit',
              fontSize: 'inherit',
              letterSpacing: 'inherit',
            }}
            aria-label={`Switch to ${l === 'ru' ? 'Russian' : 'English'}`}
          >
            {t.languageSwitcher[l]}
          </button>
        </span>
      ))}
    </div>
  );
}
