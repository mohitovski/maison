import { useMemo } from 'react';
import { clamp } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

// Generate a smooth wavy SVG path for smoke lines
function smokePath(offset: number, amplitude: number, phase: number): string {
  const w = 100; // viewBox width
  const points: string[] = [];
  for (let x = 0; x <= w; x += 5) {
    const y = 50 + Math.sin((x / w) * Math.PI * 3 + phase) * amplitude + offset;
    points.push(`${x === 0 ? 'M' : 'L'} ${x} ${y}`);
  }
  return points.join(' ');
}

export function SceneReviews({ progress, start, end }: Props) {
  const { t } = useLang();
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.05);

  const reviews = t.reviews.items;
  const reviewSpan = 1 / reviews.length;

  // Smoke line paths — only 3, very subtle
  const smokeLines = useMemo(
    () => [
      { offset: -25, amp: 8, phase: 0, delay: 0 },
      { offset: 0, amp: 6, phase: 1.5, delay: 0.3 },
      { offset: 25, amp: 10, phase: 3, delay: 0.6 },
    ],
    []
  );

  return (
    <section
      className="scene"
      style={{
        opacity: enter,
        background: '#000',
        zIndex: 9,
      }}
    >
      <div className="scene__inner">
        {/* grain */}
        <div className="grain absolute inset-0 pointer-events-none" style={{ opacity: 0.04 }} />

        {/* smoke lines — subtle, animated */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none"
          viewBox="0 0 100 100"
          preserveAspectRatio="xMidYMid slice"
          style={{ opacity: enter * 0.5 }}
        >
          {smokeLines.map((s, i) => (
            <g key={i} className="smoke-line" style={{ animationDelay: `${s.delay}s` }}>
              <path
                d={smokePath(s.offset, s.amp, s.phase)}
                stroke="rgba(130,130,138,0.15)"
                strokeWidth="0.12"
                fill="none"
                strokeLinecap="round"
              />
            </g>
          ))}
        </svg>

        {/* content */}
        <div
          className="relative w-full max-w-5xl px-[6%] md:px-[8%] py-[8vh]"
          style={{ opacity: enter }}
        >
          {/* header */}
          <div
            className="text-center mb-12 md:mb-16"
            style={{
              opacity: clamp(local / 0.1),
              transform: `translate3d(0, ${mapRange(clamp(local / 0.1), 0, 1, 20, 0)}px, 0)`,
            }}
          >
            <div className="micro mb-4" style={{ color: 'rgba(130,130,138,0.6)' }}>
              {t.reviews.micro}
            </div>
            <h2
              className="font-display font-bold tracking-[-0.03em]"
              style={{
                fontSize: 'clamp(2rem, 6vw, 4.5rem)',
                color: 'var(--color-graphite-100)',
                lineHeight: 0.9,
              }}
            >
              {t.reviews.title}
            </h2>
          </div>

          {/* review cards */}
          <div className="flex flex-col gap-6 md:gap-8">
            {reviews.map((review, i) => {
              const rStart = 0.1 + i * reviewSpan;
              const rLocal = clamp((local - rStart) / (reviewSpan * 0.8));
              // blur → sharp, slight movement, scale
              const blur = (1 - rLocal) * 12;
              const ty = (1 - rLocal) * 30;
              const scale = 0.96 + rLocal * 0.04;
              const opacity = rLocal;

              // alternate side for asymmetry
              const isLeft = i % 2 === 0;

              return (
                <div
                  key={i}
                  className="review-card relative mx-auto w-full max-w-xl"
                  style={{
                    opacity,
                    transform: `translate3d(${isLeft ? -8 : 8}px, ${ty}px, 0) scale(${scale})`,
                    filter: `blur(${blur}px)`,
                    transition: 'none',
                    alignSelf: isLeft ? 'flex-start' : 'flex-end',
                  }}
                >
                  <div
                    className="relative px-6 md:px-10 py-7 md:py-9 rounded-sm"
                    style={{
                      background: 'rgba(24,24,25,0.45)',
                      backdropFilter: 'blur(12px)',
                      WebkitBackdropFilter: 'blur(12px)',
                      border: '1px solid rgba(255,255,255,0.06)',
                      boxShadow: '0 8px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.03)',
                    }}
                  >
                    {/* accent line */}
                    <div
                      className="absolute top-0 left-8 h-px"
                      style={{
                        width: '40px',
                        background: 'var(--color-accent)',
                        opacity: 0.5,
                      }}
                    />

                    {/* quote mark */}
                    <div
                      className="font-display font-light mb-4"
                      style={{
                        fontSize: '2.5rem',
                        lineHeight: 0.5,
                        color: 'var(--color-accent)',
                        opacity: 0.4,
                      }}
                    >
                      &ldquo;
                    </div>

                    {/* text */}
                    <p
                      className="font-editorial font-light text-balance"
                      style={{
                        fontSize: 'clamp(0.9rem, 1.3vw, 1.1rem)',
                        lineHeight: 1.7,
                        color: 'rgba(232,232,234,0.85)',
                      }}
                    >
                      {review.text}
                    </p>

                    {/* author */}
                    <div className="mt-6 flex items-center gap-3">
                      <div
                        className="h-px w-8"
                        style={{ background: 'rgba(201,184,154,0.4)' }}
                      />
                      <div>
                        <div
                          className="font-display font-medium"
                          style={{
                            fontSize: '0.85rem',
                            color: 'var(--color-graphite-100)',
                            letterSpacing: '0.02em',
                          }}
                        >
                          {review.author}
                        </div>
                        <div
                          className="font-mono mt-0.5"
                          style={{
                            fontSize: '0.55rem',
                            color: 'rgba(130,130,138,0.7)',
                            letterSpacing: '0.2em',
                            textTransform: 'uppercase',
                          }}
                        >
                          {review.role}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* footer mark */}
          <div
            className="mt-16 md:mt-24 text-center font-mono"
            style={{
              opacity: clamp((local - 0.92) / 0.08),
              fontSize: '0.55rem',
              letterSpacing: '0.28em',
              textTransform: 'uppercase',
              color: 'rgba(130,130,138,0.6)',
            }}
          >
            made code &amp; soul Maison #1
          </div>
        </div>
      </div>
    </section>
  );
}

function mapRange(v: number, inMin: number, inMax: number, outMin: number, outMax: number) {
  const t = clamp((v - inMin) / (inMax - inMin));
  return outMin + (outMax - outMin) * t;
}
