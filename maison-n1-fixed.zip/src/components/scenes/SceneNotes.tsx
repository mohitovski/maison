import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

export function SceneNotes({ progress, start, end }: Props) {
  const { t } = useLang();
  const NOTE_GROUPS = t.notes.groups;
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.06);

  const groupSpan = 1 / NOTE_GROUPS.length;

  return (
    <section
      className="scene"
      style={{
        opacity: enter,
        background: 'var(--color-graphite-900)',
        zIndex: 7,
      }}
    >
      <div className="scene__inner">
        {/* grain overlay */}
        <div className="grain absolute inset-0 pointer-events-none" style={{ opacity: 0.04 }} />

        {/* vertical hairlines */}
        <div className="absolute inset-0 flex justify-between px-[10%] opacity-[0.06] pointer-events-none">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="top-0 bottom-0 w-px bg-graphite-300" />
          ))}
        </div>

        <div className="relative w-full max-w-5xl px-[8%] py-[10vh]">
          {NOTE_GROUPS.map((group, gi) => {
            const gStart = gi * groupSpan;
            const gLocal = clamp((local - gStart) / groupSpan);
            const gEnter = clamp(gLocal / 0.15);
            const gActive = clamp((gLocal - 0.1) / 0.15);
            const gFade = clamp((gLocal - 0.85) / 0.15);

            // Group label slides in from left with letter-spacing spread
            const labelX = mapRange(gEnter, 0, 1, -60, 0);
            const labelSpacing = mapRange(gEnter, 0, 1, 0.5, 0.15);
            const labelOpacity = gEnter * (1 - gFade);

            return (
              <div key={group.label} className="mb-[8vh] last:mb-0">
                {/* group header */}
                <div className="flex items-baseline gap-4 mb-6">
                  <div
                    className="font-mono text-[0.6rem] uppercase"
                    style={{
                      color: 'var(--color-graphite-400)',
                      letterSpacing: '0.28em',
                      opacity: labelOpacity,
                    }}
                  >
                    {group.micro}
                  </div>
                  <div
                    className="h-px bg-graphite-500"
                    style={{
                      width: `${gActive * 30}vw`,
                      maxWidth: '200px',
                      opacity: labelOpacity * 0.5,
                    }}
                  />
                </div>

                <div
                  className="font-display font-light tracking-[-0.03em]"
                  style={{
                    fontSize: 'clamp(1.8rem, 5vw, 3.5rem)',
                    color: 'var(--color-graphite-100)',
                    opacity: labelOpacity,
                    transform: `translate3d(${labelX}px, 0, 0)`,
                    letterSpacing: `${labelSpacing}em`,
                    lineHeight: 1,
                  }}
                >
                  {group.label}
                </div>

                {/* notes list */}
                <div className="mt-5 flex flex-col gap-1.5">
                  {group.notes.map((note, ni) => {
                    const noteEnter = clamp((gLocal - 0.2 - ni * 0.08) / 0.15);
                    const noteY = (1 - noteEnter) * 24;
                    const noteBlur = (1 - noteEnter) * 8;
                    // letters slightly spread on appear
                    const ls = mapRange(noteEnter, 0, 1, 0.3, 0.02);

                    return (
                      <div key={note} className="flex items-center gap-4">
                        <div
                          className="font-mono text-[0.55rem]"
                          style={{
                            color: 'var(--color-graphite-500)',
                            opacity: noteEnter * (1 - gFade),
                          }}
                        >
                          {String(ni + 1).padStart(2, '0')}
                        </div>
                        <div
                          className="font-editorial font-light"
                          style={{
                            fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
                            color: 'var(--color-graphite-200)',
                            opacity: noteEnter * (1 - gFade),
                            transform: `translate3d(0, ${noteY}px, 0)`,
                            filter: `blur(${noteBlur}px)`,
                            letterSpacing: `${ls}em`,
                            transition: 'none',
                          }}
                        >
                          {note}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* footer */}
        <div
          className="absolute bottom-[6%] left-1/2 -translate-x-1/2 micro text-graphite-500"
          style={{ opacity: clamp((local - 0.92) / 0.08) }}
        >
          {t.notes.footer}
        </div>
      </div>
    </section>
  );
}
