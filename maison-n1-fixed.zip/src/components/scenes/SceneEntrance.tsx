import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

function readCursorVel() {
  if (typeof window === 'undefined') return { x: 0, y: 0 };
  const vx = Number(getComputedStyle(document.documentElement).getPropertyValue('--cursor-vx')) || 0;
  const vy = Number(getComputedStyle(document.documentElement).getPropertyValue('--cursor-vy')) || 0;
  return { x: vx, y: vy };
}

export function SceneEntrance({ progress, start, end }: Props) {
  const { t } = useLang();
  const MANIFEST_WORDS = t.entrance.words;
  const local = clamp((progress - start) / (end - start));
  const exit = clamp((progress - (start + 0.7 * (end - start))) / (0.3 * (end - start)));

  const parallax = readCursorVel();

  const titleOpacity = mapRange(local, 0, 0.15, 1, 1) * (1 - exit);
  const titleShift = mapRange(local, 0, 0.15, 0, -10) - exit * 60;
  const subOpacity = mapRange(local, 0.05, 0.25, 0, 1) * (1 - exit);

  return (
    <section
      className="scene scene--active"
      style={{
        opacity: 1 - exit,
        transform: `translate3d(0, ${exit * -40}px, 0)`,
        background: 'var(--color-graphite-100)',
      }}
    >
      <div className="scene__inner">
        {/* grid lines */}
        <div className="absolute inset-0 opacity-[0.06] pointer-events-none">
          {[...Array(7)].map((_, i) => (
            <div
              key={i}
              className="absolute top-0 bottom-0 w-px bg-graphite-900"
              style={{ left: `${(i + 1) * 12.5}%` }}
            />
          ))}
        </div>

        {/* corner micro */}
        <div className="absolute top-[14%] left-[8%] micro">{t.entrance.volume}</div>
        <div className="absolute top-[14%] right-[8%] micro text-right">{t.entrance.coords}</div>
        <div className="absolute bottom-[16%] left-[8%] micro">{t.entrance.study}</div>

        {/* main title */}
        <div
          className="relative text-center"
          style={{
            opacity: titleOpacity,
            transform: `translate3d(0, ${titleShift}px, 0)`,
          }}
        >
          <div className="micro mb-6 md:mb-10">{t.entrance.eauDeParfum}</div>
          <h1
            className="font-display font-bold tracking-[-0.04em] leading-[0.85] text-graphite-900"
            style={{
              fontSize: 'clamp(3.5rem, 13vw, 11rem)',
              transform: `translate3d(${parallax.x * -0.4}px, ${parallax.y * -0.4}px, 0)`,
            }}
          >
            <span className="word block">{t.entrance.titleTop}</span>
            <span className="word block italic font-editorial font-light tracking-tight" style={{ fontSize: '0.78em' }}>
              {t.entrance.titleBottom}
            </span>
          </h1>

          <div
            className="mt-8 md:mt-12 max-w-md mx-auto font-editorial text-graphite-500 text-balance"
            style={{
              opacity: subOpacity,
              fontSize: 'clamp(0.875rem, 1.1vw, 1.05rem)',
              lineHeight: 1.6,
              transform: `translate3d(${parallax.x * 0.3}px, ${parallax.y * 0.3}px, 0)`,
            }}
          >
            {t.entrance.subtitle}
          </div>
        </div>

        {/* manifest words */}
        {MANIFEST_WORDS.map((w, i) => {
          const appear = clamp((local - 0.12 - i * 0.06) / 0.18);
          const blur = (1 - appear) * 12;
          const ty = (1 - appear) * 30;
          const depth = (i % 3) - 1;
          const px = parallax.x * (0.15 + i * 0.05);
          const py = parallax.y * (0.15 + i * 0.05);
          const pos = positions[i % positions.length];
          return (
            <span
              key={w}
              className="word absolute font-display font-light text-graphite-700 select-none"
              style={{
                left: pos.l,
                top: pos.t,
                fontSize: pos.s,
                opacity: appear * (1 - exit),
                transform: `translate3d(${px + depth * 8}px, ${ty + py}px, 0)`,
                filter: `blur(${blur}px)`,
                letterSpacing: '-0.02em',
                transition: 'none',
              }}
            >
              {w}
            </span>
          );
        })}

        {/* scroll cue */}
        <div
          className="absolute bottom-[8%] left-1/2 -translate-x-1/2 micro flex items-center gap-3"
          style={{ opacity: subOpacity * (1 - exit) }}
        >
          <span className="block w-8 h-px bg-current" />
          {t.entrance.scrollCue}
          <span className="block w-8 h-px bg-current" />
        </div>
      </div>
    </section>
  );
}

const positions = [
  { l: '12%', t: '28%', s: 'clamp(2rem, 5vw, 4rem)' },
  { l: '74%', t: '32%', s: 'clamp(1.8rem, 4.5vw, 3.5rem)' },
  { l: '20%', t: '68%', s: 'clamp(2.2rem, 6vw, 5rem)' },
  { l: '66%', t: '70%', s: 'clamp(1.6rem, 4vw, 3rem)' },
  { l: '44%', t: '20%', s: 'clamp(1.4rem, 3vw, 2.2rem)' },
  { l: '82%', t: '58%', s: 'clamp(1.8rem, 4vw, 3.2rem)' },
  { l: '8%', t: '52%', s: 'clamp(1.5rem, 3.5vw, 2.6rem)' },
];
