import { useMemo, useEffect } from 'react';
import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

const LINES = Array.from({ length: 26 }, (_, i) => i);

function useResponsiveLightRadius() {
  useEffect(() => {
    const update = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      // Larger radius — covers significantly more area
      // Desktop: 380px, mobile: 45% of min dimension
      const r = vw < 768
        ? Math.min(vw, vh) * 0.45
        : 380;
      document.documentElement.style.setProperty('--light-r', `${r}px`);
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);
}

export function SceneDarkness({ progress, start, end }: Props) {
  const { t } = useLang();
  useResponsiveLightRadius();
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.25);
  const exit = clamp((local - 0.82) / 0.18);

  const bg = useMemo(() => {
    const g = mapRange(enter, 0, 1, 0.96, 1);
    return `rgb(${Math.round(14 * (1 - g))}, ${Math.round(14 * (1 - g))}, ${Math.round(16 * (1 - g))})`;
  }, [enter]);

  const lineGrow = mapRange(local, 0.15, 0.85, 0, 1);
  const glow = mapRange(local, 0.3, 0.9, 0, 1) * (1 - exit);

  return (
    <section
      className="scene"
      style={{
        opacity: enter * (1 - exit),
        background: bg,
        zIndex: 2,
      }}
    >
      <div className="scene__inner vignette">
        {/* faint base grid visible only near light */}
        <div
          className="absolute inset-0"
          style={{
            opacity: enter * 0.5,
            background:
              'radial-gradient(circle var(--light-r) at var(--cursor-x) var(--cursor-y), rgba(200,200,210,0.06), transparent 70%)',
          }}
        />

        {/* glowing vertical lines, revealed by light mask */}
        <div
          className="absolute inset-0 light-mask"
          style={{ opacity: enter * (1 - exit) }}
        >
          <div className="absolute inset-0 flex justify-between px-[6%]">
            {LINES.map((i) => {
              const delay = (i % 7) / 7;
              const grow = clamp((lineGrow - delay) * 1.6);
              const h = `${grow * 100}%`;
              const isAccent = i % 6 === 0;
              return (
                <div
                  key={i}
                  className="relative top-1/2 -translate-y-1/2"
                  style={{ width: '1px', height: '100%' }}
                >
                  <div
                    style={{
                      position: 'absolute',
                      bottom: 0,
                      left: 0,
                      width: '1px',
                      height: h,
                      background: isAccent
                        ? 'linear-gradient(to top, rgba(201,184,154,0.0), rgba(201,184,154,0.85), rgba(201,184,154,0.0))'
                        : 'linear-gradient(to top, rgba(220,220,228,0.0), rgba(220,220,228,0.7), rgba(220,220,228,0.0))',
                      boxShadow: isAccent
                        ? `0 0 6px rgba(201,184,154,${0.4 * glow})`
                        : `0 0 5px rgba(220,220,228,${0.35 * glow})`,
                      opacity: 0.9,
                    }}
                  />
                </div>
              );
            })}
          </div>

          {/* horizontal architectural cross-lines */}
          <div className="absolute inset-0 flex flex-col justify-between py-[12%]">
            {[...Array(6)].map((_, i) => {
              const grow = clamp((lineGrow - i * 0.08) * 1.4);
              return (
                <div
                  key={i}
                  className="mx-[6%]"
                  style={{
                    height: '1px',
                    width: `${grow * 100}%`,
                    background: 'linear-gradient(to right, transparent, rgba(220,220,228,0.4), transparent)',
                    boxShadow: `0 0 4px rgba(220,220,228,${0.2 * glow})`,
                  }}
                />
              );
            })}
          </div>
        </div>

        {/* cursor light glow */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            opacity: enter * (1 - exit),
            background:
              'radial-gradient(circle var(--light-r) at var(--cursor-x) var(--cursor-y), rgba(220,220,230,0.10), rgba(220,220,230,0.03) 40%, transparent 70%)',
          }}
        />

        {/* center whisper text, revealed only under light */}
        <div
          className="absolute inset-0 flex items-center justify-center text-center light-mask"
          style={{ opacity: enter * (1 - exit) }}
        >
          <div>
            <div className="micro text-graphite-300 mb-4">{t.darkness.chapter}</div>
            <div
              className="font-display font-light tracking-[-0.03em] text-graphite-200"
              style={{ fontSize: 'clamp(1.6rem, 7vw, 5.5rem)', lineHeight: 0.9 }}
            >
              {t.darkness.title}
              <br />
              <span className="italic font-editorial text-graphite-400">{t.darkness.titleItalic}</span>
            </div>
          </div>
        </div>

        {/* edge micro */}
        <div
          className="absolute bottom-[14%] left-[8%] micro text-graphite-500"
          style={{ opacity: enter * (1 - exit) }}
        >
          {t.darkness.move}
        </div>
      </div>
    </section>
  );
}
