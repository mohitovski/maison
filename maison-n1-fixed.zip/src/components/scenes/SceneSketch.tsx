import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { Bottle } from '@/components/Bottle';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

// Hand-drawn-ish path generator: slightly jittered line
function jitterPath(x1: number, y1: number, x2: number, y2: number, j: number = 2.5): string {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.sqrt(dx * dx + dy * dy);
  const nx = -dy / len;
  const ny = dx / len;
  // two midpoints with jitter perpendicular to the line
  const m1x = x1 + dx * 0.35 + nx * (Math.sin(x1 * 0.7) * j);
  const m1y = y1 + dy * 0.35 + ny * (Math.sin(y1 * 0.7) * j);
  const m2x = x1 + dx * 0.7 + nx * (Math.cos(x2 * 0.5) * j * 0.8);
  const m2y = y1 + dy * 0.7 + ny * (Math.cos(y2 * 0.5) * j * 0.8);
  return `M${x1},${y1} C${m1x},${m1y} ${m2x},${m2y} ${x2},${y2}`;
}

export function SceneSketch({ progress, start, end }: Props) {
  const { t } = useLang();
  // Technical-sheet annotations + price, arranged around the bottle
  const ALL_ANNOTATIONS = [...t.sketch.annotations, { label: t.price.label, value: t.price.value }];
  const ANNOTATIONS = ALL_ANNOTATIONS.map((a, i) => ({
    ...a,
    angle: [-110, -65, -20, 20, 75, 145, 200][i],
    dist: [26, 24, 25, 27, 25, 23, 26][i],
  }));
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.1);
  const exit = clamp((local - 0.9) / 0.1);

  // Bottle emerges from the blur of the previous scene
  const bottleReveal = clamp((local - 0.02) / 0.2);
  const bottleBlur = (1 - bottleReveal) * 20;
  const bottleScale = 0.85 + bottleReveal * 0.15;

  // Pencil lines draw in progressively
  const lineDraw = clamp((local - 0.15) / 0.4);

  // Annotations appear one by one
  const annotStart = 0.3;

  return (
    <section
      className="scene"
      style={{
        opacity: enter,
        background: 'var(--color-graphite-50)',
        zIndex: 6,
      }}
    >
      <div className="scene__inner">
        {/* SVG overlay for pencil lines + arrows */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="-50 -50 100 100"
          preserveAspectRatio="xMidYMid meet"
          style={{ opacity: enter * (1 - exit) }}
        >
          {/* hand-drawn bottle outline sketch (decorative, behind actual bottle) */}
          <g
            stroke="var(--color-graphite-400)"
            strokeWidth="0.18"
            fill="none"
            strokeLinecap="round"
            opacity={0.35 * lineDraw}
          >
            {/* cap */}
            <path d={jitterPath(-6, -30, 6, -30, 1.2)} />
            <path d={jitterPath(-6, -30, -6, -18, 1.2)} />
            <path d={jitterPath(6, -30, 6, -18, 1.2)} />
            <path d={jitterPath(-6, -18, 6, -18, 1)} />
            {/* neck */}
            <path d={jitterPath(-4, -18, -4, -14, 0.8)} />
            <path d={jitterPath(4, -18, 4, -14, 0.8)} />
            {/* body */}
            <path d={jitterPath(-4, -14, -12, -8, 1.5)} />
            <path d={jitterPath(4, -14, 12, -8, 1.5)} />
            <path d={jitterPath(-12, -8, -12, 28, 1.5)} />
            <path d={jitterPath(12, -8, 12, 28, 1.5)} />
            <path d={jitterPath(-12, 28, -10, 32, 1)} />
            <path d={jitterPath(12, 28, 10, 32, 1)} />
            <path d={jitterPath(-10, 32, 10, 32, 1)} />
            {/* center line */}
            <path d={jitterPath(0, -14, 0, 32, 0.6)} opacity="0.5" />
          </g>

          {/* annotation arrows */}
          {ANNOTATIONS.map((a, i) => {
            const ang = (a.angle * Math.PI) / 180;
            const ax = Math.cos(ang) * a.dist;
            const ay = Math.sin(ang) * a.dist * 0.85;
            // arrow target: edge of bottle in that direction
            const tLen = 8;
            const tx = Math.cos(ang) * tLen;
            const ty = Math.sin(ang) * tLen * 0.85;

            const ap = clamp((local - annotStart - i * 0.07) / 0.15);
            const drawLen = ap; // 0..1 for dash offset
            const labelOpacity = clamp((ap - 0.5) * 2);

            // For stroke-dash reveal, we need pathLength
            return (
              <g key={i} opacity={labelOpacity}>
                {/* line from annotation to bottle */}
                <path
                  d={jitterPath(ax, ay, tx, ty, 0.8)}
                  stroke="var(--color-graphite-500)"
                  strokeWidth="0.15"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray="40"
                  strokeDashoffset={40 * (1 - drawLen)}
                />
                {/* small dot at bottle end */}
                <circle cx={tx} cy={ty} r="0.4" fill="var(--color-graphite-500)" />
                {/* label dot at annotation end */}
                <circle cx={ax} cy={ay} r="0.3" fill="var(--color-accent)" />
              </g>
            );
          })}
        </svg>

        {/* The actual bottle */}
        <div
          className="absolute"
          style={{
            width: 'min(32vw, 280px)',
            height: 'min(62vh, 600px)',
            transform: `translate3d(0, 0, 0) scale(${bottleScale})`,
            opacity: bottleReveal * (1 - exit),
            filter: `blur(${bottleBlur}px)`,
            zIndex: 7,
          }}
        >
          <Bottle />
        </div>

        {/* Annotation text labels (HTML for crisp typography) */}
        {ANNOTATIONS.map((a, i) => {
          const ang = (a.angle * Math.PI) / 180;
          const ax = Math.cos(ang) * a.dist;
          const ay = Math.sin(ang) * a.dist * 0.85;
          const ap = clamp((local - annotStart - i * 0.07) / 0.15);
          const labelOpacity = clamp((ap - 0.5) * 2);

          // text alignment: flip if on left side
          const isLeft = ax < 0;
          return (
            <div
              key={i}
              className="absolute font-mono"
              style={{
                left: `${50 + ax}vw`,
                top: `${50 + ay}vh`,
                transform: `translate(${isLeft ? '-100%' : '0'}, -50%)`,
                opacity: labelOpacity * enter * (1 - exit),
                textAlign: isLeft ? 'right' : 'left',
                paddingLeft: isLeft ? '0' : '8px',
                paddingRight: isLeft ? '8px' : '0',
              }}
            >
              <div
                className="font-display font-bold"
                style={{
                  fontSize: 'clamp(1rem, 2vw, 1.6rem)',
                  color: 'var(--color-graphite-900)',
                  lineHeight: 1,
                  letterSpacing: '-0.02em',
                }}
              >
                {a.value}
              </div>
              <div
                className="mt-1"
                style={{
                  fontSize: 'clamp(0.5rem, 0.7vw, 0.62rem)',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  color: 'var(--color-graphite-500)',
                }}
              >
                {a.label}
              </div>
            </div>
          );
        })}

        {/* micro labels */}
        <div
          className="absolute top-[14%] left-[8%] micro"
          style={{ opacity: enter * (1 - exit) }}
        >
          {t.sketch.microLeft}
        </div>
        <div
          className="absolute top-[14%] right-[8%] micro text-right"
          style={{ opacity: enter * (1 - exit) }}
        >
          {t.sketch.microRight}
        </div>
      </div>
    </section>
  );
}
