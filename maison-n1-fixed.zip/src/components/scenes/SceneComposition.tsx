import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

// Orbit radius per note (vw) — slight asymmetry for organic feel
const ORBIT_R = [16, 16, 16, 16];
// Base angle offset per note (radians)
const BASE_ANGLE = [0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2];

export function SceneComposition({ progress, start, end }: Props) {
  const { t } = useLang();
  const NOTES = t.composition.notes;
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.08);
  const exit = clamp((local - 0.88) / 0.12);

  // Each note appears at staggered thresholds
  const noteProgress = NOTES.map((_, i) =>
    clamp((local - 0.05 - i * 0.08) / 0.12)
  );

  // Orbit begins after all notes visible
  const orbitStart = 0.42;
  const orbit = clamp((local - orbitStart) / (1 - orbitStart));
  // Very slow rotation — half turn across the whole orbit phase
  const angle = orbit * Math.PI * 0.6;

  // Blur/dissolve at the end (transition into bottle+sketch)
  const dissolve = clamp((local - 0.82) / 0.18);
  const blurPx = dissolve * 24;
  const dissolveOpacity = 1 - dissolve * 0.85;

  return (
    <section
      className="scene"
      style={{
        opacity: enter * (1 - exit),
        background: 'var(--color-graphite-50)',
        zIndex: 5,
      }}
    >
      <div className="scene__inner">
        {/* center marker */}
        <div
          className="absolute"
          style={{
            opacity: enter * (1 - exit) * 0.3,
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: 'var(--color-graphite-400)',
          }}
        />
        {/* faint orbit ring */}
        <div
          className="absolute rounded-full"
          style={{
            width: `${ORBIT_R[0] * 2}vw`,
            height: `${ORBIT_R[0] * 2}vw`,
            border: '1px solid var(--color-graphite-200)',
            opacity: enter * orbit * 0.5 * (1 - exit),
          }}
        />

        {NOTES.map((note, i) => {
          const np = noteProgress[i];
          // materialize: blur + scale + opacity
          const matBlur = (1 - np) * 16;
          const matScale = 0.7 + np * 0.3;
          const matOpacity = np;

          const a = BASE_ANGLE[i] + angle;
          const r = ORBIT_R[i];
          const x = Math.cos(a) * r;
          const y = Math.sin(a) * r * 0.62; // squashed orbit for perspective

          return (
            <div
              key={note}
              className="absolute font-display font-light select-none"
              style={{
                fontSize: 'clamp(1.8rem, 5vw, 4rem)',
                color: 'var(--color-graphite-800)',
                letterSpacing: '0.02em',
                opacity: matOpacity * dissolveOpacity * (1 - exit),
                transform: `translate3d(${x}vw, ${y}vh, 0) scale(${matScale})`,
                filter: `blur(${matBlur + blurPx}px)`,
                transition: 'none',
                willChange: 'transform, opacity, filter',
              }}
            >
              {note}
            </div>
          );
        })}

        {/* micro label */}
        <div
          className="absolute bottom-[12%] left-1/2 -translate-x-1/2 micro"
          style={{ opacity: enter * (1 - exit) * (1 - dissolve) }}
        >
          {t.composition.label}
        </div>
        <div
          className="absolute top-[14%] left-[8%] micro"
          style={{ opacity: enter * (1 - exit) }}
        >
          {t.composition.micro}
        </div>
      </div>
    </section>
  );
}
