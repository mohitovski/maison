import { useMemo } from 'react';
import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

// Generate a hand-drawn heart path with natural jitter.
// The heart is drawn as two cubic bezier halves, with slight
// perpendicular displacement on control points for a pencil feel.
function buildHeartPath(jitter: number, seed: number): string {
  // Pseudo-random based on seed for stable jitter
  const rand = (n: number) => {
    const v = Math.sin(n * 12.9898 + seed * 78.233) * 43758.5453;
    return (v - Math.floor(v)) * 2 - 1;
  };

  // Heart shape in viewBox 0..200 x 0..190
  // Top center dip at (100, 60), left lobe peaks at ~(40, 20), right at ~(160, 20)
  // Bottom point at (100, 175)
  const cx = 100;
  const dipY = 60;
  const bottomY = 175;

  // Left half: from bottom point up through left lobe to center dip
  const lp1x = 100 + rand(1) * jitter;
  const lp1y = 150 + rand(2) * jitter;
  const lp2x = 20 + rand(3) * jitter;
  const lp2y = 70 + rand(4) * jitter;
  const lp3x = 20 + rand(5) * jitter;
  const lp3y = 10 + rand(6) * jitter;
  const lp4x = cx + rand(7) * jitter;
  const lp4y = dipY + rand(8) * jitter;

  // Right half: from center dip through right lobe to bottom point
  const rp1x = cx + rand(9) * jitter;
  const rp1y = dipY + rand(10) * jitter;
  const rp2x = 180 + rand(11) * jitter;
  const rp2y = 10 + rand(12) * jitter;
  const rp3x = 180 + rand(13) * jitter;
  const rp3y = 70 + rand(14) * jitter;
  const rp4x = 100 + rand(15) * jitter;
  const rp4y = 150 + rand(16) * jitter;

  return (
    `M ${cx} ${bottomY} ` +
    `C ${lp1x} ${lp1y}, ${lp2x} ${lp2y}, ${lp3x} ${lp3y} ` +
    `C ${lp4x} ${lp4y}, ${lp4x} ${lp4y}, ${lp4x} ${lp4y} ` +
    `C ${lp3x} ${lp3y}, ${lp2x} ${lp2y}, ${lp1x} ${lp1y} ` +
    `L ${cx} ${bottomY} ` +
    `M ${rp1x} ${rp1y} ` +
    `C ${rp2x} ${rp2y}, ${rp3x} ${rp3y}, ${rp4x} ${rp4y} ` +
    `L ${cx} ${bottomY}`
  );
}

// Simpler, cleaner heart — two bezier curves
function buildCleanHeart(jitter: number, seed: number): string {
  const rand = (n: number) => {
    const v = Math.sin(n * 12.9898 + seed * 78.233) * 43758.5453;
    return (v - Math.floor(v)) * 2 - 1;
  };

  const j = () => rand(Math.random() * 100) * jitter;

  // Start at bottom tip
  const bx = 100, by = 175;
  // Left lobe
  const c1x = 30 + j(), c1y = 130 + j();
  const c2x = -10 + j(), c2y = 50 + j();
  const c3x = 50 + j(), c3y = 5 + j();
  // Center dip
  const mx = 100, my = 55;
  // Right lobe
  const c4x = 150 + j(), c4y = 5 + j();
  const c5x = 210 + j(), c5y = 50 + j();
  const c6x = 170 + j(), c6y = 130 + j();

  return (
    `M ${bx} ${by} ` +
    `C ${c1x} ${c1y}, ${c2x} ${c2y}, ${c3x} ${c3y} ` +
    `S ${mx} ${my - 10}, ${mx} ${my} ` +
    `S ${c4x} ${c4y}, ${c5x} ${c5y} ` +
    `S ${c6x} ${c6y}, ${bx} ${by} Z`
  );
}

export function SceneHeart({ progress, start, end }: Props) {
  const { t } = useLang();
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.05);

  // Phase 1: draw the outline (0.05 .. 0.50)
  const drawPhase = clamp((local - 0.05) / 0.45);
  // Phase 2: fill the heart (0.50 .. 0.85)
  const fillPhase = clamp((local - 0.50) / 0.35);
  // Phase 3: hold + caption (0.85 .. 1.0)
  const holdPhase = clamp((local - 0.85) / 0.15);

  // Build a stable jittered path
  const heartPath = useMemo(() => buildCleanHeart(3.5, 42), []);

  // For stroke-dash reveal we need the approximate path length.
  // We use a large dasharray and animate dashoffset.
  const pathLen = 520; // approx for this heart shape
  const dashOffset = pathLen * (1 - drawPhase);

  // Fill: layered organic textures
  // We use multiple soft radial gradients with noise-like positioning
  const fillOpacity = fillPhase;

  // Subtle pulsing glow that grows with fill
  const glowR = mapRange(fillPhase, 0, 1, 30, 120);
  const glowOpacity = fillPhase * 0.25;

  return (
    <section
      className="scene"
      style={{
        opacity: enter,
        background: '#000',
        zIndex: 8,
      }}
    >
      <div className="scene__inner">
        {/* grain */}
        <div className="grain absolute inset-0 pointer-events-none" style={{ opacity: 0.05 }} />

        {/* glow behind heart */}
        <div
          className="absolute"
          style={{
            width: `${glowR * 2}px`,
            height: `${glowR * 2}px`,
            borderRadius: '50%',
            background: `radial-gradient(circle, rgba(201,184,154,${glowOpacity}), transparent 70%)`,
            filter: 'blur(40px)',
            opacity: enter,
          }}
        />

        <svg
          viewBox="0 0 200 190"
          className="absolute"
          style={{
            width: 'min(80vw, 420px)',
            height: 'auto',
            opacity: enter,
            filter: 'drop-shadow(0 0 12px rgba(201,184,154,0.15))',
          }}
        >
          <defs>
            {/* Organic fill: layered gradients simulating pencil shading */}
            <radialGradient id="heartFill1" cx="0.5" cy="0.4" r="0.6">
              <stop offset="0%" stopColor="#c9b89a" stopOpacity="0.35" />
              <stop offset="60%" stopColor="#8a7a5e" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#3a3530" stopOpacity="0.05" />
            </radialGradient>
            <radialGradient id="heartFill2" cx="0.3" cy="0.6" r="0.4">
              <stop offset="0%" stopColor="#d9c8a8" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#d9c8a8" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="heartFill3" cx="0.7" cy="0.3" r="0.35">
              <stop offset="0%" stopColor="#e8e6df" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#e8e6df" stopOpacity="0" />
            </radialGradient>
            {/* Noise filter for organic texture */}
            <filter id="organicNoise">
              <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="4" seed="7" />
              <feColorMatrix values="0 0 0 0 0.78  0 0 0 0 0.72  0 0 0 0 0.6  0 0 0 0.4 0" />
              <feComposite in2="SourceGraphic" operator="in" />
            </filter>
            {/* Pencil texture filter for the stroke */}
            <filter id="pencilTexture">
              <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" />
              <feDisplacementMap in="SourceGraphic" scale="1.5" />
            </filter>
          </defs>

          {/* Organic fill layers — revealed progressively */}
          <g style={{ opacity: fillOpacity }}>
            <path d={heartPath} fill="url(#heartFill1)" />
            <path d={heartPath} fill="url(#heartFill2)" />
            <path d={heartPath} fill="url(#heartFill3)" />
            {/* Noise texture overlay */}
            <path d={heartPath} fill="#c9b89a" opacity={fillPhase * 0.08} filter="url(#organicNoise)" />
          </g>

          {/* The pencil stroke — drawn progressively via dash */}
          <path
            d={heartPath}
            fill="none"
            stroke="#e8e6df"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={pathLen}
            strokeDashoffset={dashOffset}
            opacity={0.85}
          />
          {/* Second pass — slightly offset, thinner, for hand-drawn double-line feel */}
          <path
            d={heartPath}
            fill="none"
            stroke="#c9b89a"
            strokeWidth="0.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={pathLen}
            strokeDashoffset={dashOffset}
            opacity={0.4 * drawPhase}
            transform="translate(1.2, 0.8)"
          />
        </svg>

        {/* micro caption */}
        <div
          className="absolute bottom-[14%] left-1/2 -translate-x-1/2 text-center"
          style={{ opacity: enter * holdPhase }}
        >
          <div className="micro text-graphite-500 mb-2" style={{ color: 'rgba(130,130,138,0.7)' }}>
            {t.heart.micro}
          </div>
          <div
            className="font-display font-light italic"
            style={{
              fontSize: 'clamp(0.9rem, 1.6vw, 1.3rem)',
              color: 'rgba(201,184,154,0.7)',
              letterSpacing: '0.05em',
            }}
          >
            {t.heart.caption}
          </div>
        </div>
      </div>
    </section>
  );
}
