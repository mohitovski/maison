import { useMemo } from 'react';
import { clamp, mapRange, lerp } from '@/hooks/useScrollProgress';
import { Bottle } from '@/components/Bottle';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

// Background color stops through the scene
const BG_STOPS: Array<{ t: number; rgb: [number, number, number] }> = [
  { t: 0.0, rgb: [246, 246, 247] }, // white
  { t: 0.25, rgb: [200, 200, 205] }, // light grey
  { t: 0.5, rgb: [52, 52, 58] }, // graphite
  { t: 0.72, rgb: [14, 14, 16] }, // near black
  { t: 1.0, rgb: [150, 160, 172] }, // cold blue-grey
];

function bgAt(t: number): string {
  const c = clamp(t);
  for (let i = 1; i < BG_STOPS.length; i++) {
    const a = BG_STOPS[i - 1];
    const b = BG_STOPS[i];
    if (c <= b.t) {
      const k = (c - a.t) / (b.t - a.t);
      const r = Math.round(lerp(a.rgb[0], b.rgb[0], k));
      const g = Math.round(lerp(a.rgb[1], b.rgb[1], k));
      const bl = Math.round(lerp(a.rgb[2], b.rgb[2], k));
      return `rgb(${r}, ${g}, ${bl})`;
    }
  }
  const last = BG_STOPS[BG_STOPS.length - 1].rgb;
  return `rgb(${last[0]}, ${last[1]}, ${last[2]})`;
}

function textRgbAt(t: number): string {
  // text dark on light bg, light on dark bg
  if (t < 0.4) return '26, 26, 30';
  if (t < 0.6) return '180, 180, 188';
  return '230, 232, 238';
}

export function SceneBottle({ progress, start, end }: Props) {
  const { t } = useLang();
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.08);
  const exit = clamp((local - 0.93) / 0.07);

  // Phase split: 0..0.62 color morph + text, 0.62..1 recede
  const recede = clamp((local - 0.62) / 0.38);

  const bg = useMemo(() => bgAt(local), [local]);
  const textRgb = useMemo(() => textRgbAt(local), [local]);

  // bottle scale: large at start, recedes near end
  const scale = lerp(1, 0.32, recede * recede);
  const bottleY = lerp(0, 18, recede); // sinks onto shelf
  const bottleOpacity = enter * (1 - exit);

  // text behind: drifts horizontally for parallax depth
  const textX = mapRange(local, 0, 1, -30, 30);
  const textScale = lerp(1, 1.15, recede);

  // shelf shadow grows as bottle lands
  const shadowW = lerp(0, 38, recede);
  const shadowO = lerp(0, 0.45, recede);

  // subtle cursor parallax for bottle
  const px = typeof window !== 'undefined'
    ? (Number(getComputedStyle(document.documentElement).getPropertyValue('--cursor-vx')) || 0)
    : 0;
  const py = typeof window !== 'undefined'
    ? (Number(getComputedStyle(document.documentElement).getPropertyValue('--cursor-vy')) || 0)
    : 0;

  return (
    <section
      className="scene"
      style={{
        opacity: enter,
        background: bg,
        zIndex: 3,
        transition: 'opacity 0.2s linear',
      }}
    >
      <div className="scene__inner">
        {/* huge text BEHIND the bottle */}
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{
            opacity: enter * (1 - exit * 0.5),
            transform: `translate3d(${textX + px * 0.4}px, ${py * 0.4}px, 0) scale(${textScale})`,
          }}
        >
          <div
            className="font-display font-bold leading-[0.82] text-center select-none"
            style={{
              fontSize: 'clamp(4rem, 17vw, 15rem)',
              color: `rgba(${textRgb}, ${0.16 + recede * 0.06})`,
              letterSpacing: '-0.05em',
              width: 'min(90vw, 1100px)',
            }}
          >
            <div>{t.bottle.textTop}</div>
            <div className="italic font-editorial font-light" style={{ fontSize: '0.82em' }}>
              {t.bottle.textMiddle}
            </div>
            <div>{t.bottle.textBottom}</div>
          </div>
        </div>

        {/* bottle in FRONT */}
        <div
          className="absolute"
          style={{
            width: 'min(42vw, 360px)',
            height: 'min(78vh, 760px)',
            transform: `translate3d(${px * -0.5}px, ${bottleY + py * -0.5}px, 0) scale(${scale})`,
            opacity: bottleOpacity,
            zIndex: 5,
          }}
        >
          <Bottle />
        </div>

        {/* shelf shadow under bottle */}
        <div
          className="absolute"
          style={{
            bottom: '14%',
            left: '50%',
            width: `${shadowW}vw`,
            height: '14px',
            transform: 'translateX(-50%)',
            background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.5), transparent 70%)',
            opacity: shadowO * bottleOpacity,
            zIndex: 4,
          }}
        />

        {/* shelf line */}
        <div
          className="absolute"
          style={{
            bottom: '15%',
            left: '50%',
            width: '60vw',
            height: '1px',
            transform: 'translateX(-50%)',
            background: `rgba(${textRgb}, ${0.15 * recede})`,
            opacity: recede * bottleOpacity,
            zIndex: 4,
          }}
        />

        {/* side micro labels */}
        <div
          className="absolute top-[16%] left-[6%] micro"
          style={{ color: `rgba(${textRgb}, 0.6)`, opacity: enter * (1 - exit) }}
        >
          {t.bottle.label}
        </div>
        <div
          className="absolute top-[16%] right-[6%] micro text-right"
          style={{ color: `rgba(${textRgb}, 0.6)`, opacity: enter * (1 - exit) }}
        >
          {t.bottle.volume}
        </div>
        <div
          className="absolute bottom-[8%] left-1/2 -translate-x-1/2 micro"
          style={{ color: `rgba(${textRgb}, 0.55)`, opacity: enter * (1 - exit) * recede }}
        >
          {t.bottle.subLabel}
        </div>
      </div>
    </section>
  );
}
