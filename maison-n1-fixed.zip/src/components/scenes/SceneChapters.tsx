import { clamp, mapRange } from '@/hooks/useScrollProgress';
import { useLang } from '@/i18n/LanguageContext';

type Props = { progress: number; start: number; end: number };

export function SceneChapters({ progress, start, end }: Props) {
  const { t } = useLang();
  const CHAPTERS = t.chapters.items;
  const local = clamp((progress - start) / (end - start));
  const enter = clamp(local / 0.06);

  // slide-out of the previous composition (scene 5)
  const slideOut = clamp(local / 0.08);
  const slideX = slideOut * 120; // vw

  // chapter progress: 4 chapters across local 0.1..1
  const chapterSpan = (1 - 0.1) / CHAPTERS.length;

  return (
    <section
      className="scene"
      style={{
        opacity: enter,
        background: 'var(--color-graphite-50)',
        zIndex: 4,
      }}
    >
      <div className="scene__inner">
        {/* faint vertical grid */}
        <div className="absolute inset-0 opacity-[0.05] pointer-events-none">
          {[...Array(9)].map((_, i) => (
            <div
              key={i}
              className="absolute top-0 bottom-0 w-px bg-graphite-900"
              style={{ left: `${(i + 1) * 10}%` }}
            />
          ))}
        </div>

        {/* the "old composition" sliding out right (a ghost of the bottle scene) */}
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{
            transform: `translate3d(${slideX}vw, 0, 0)`,
            opacity: 1 - slideOut,
          }}
        >
          <div
            className="font-display font-bold text-graphite-200 select-none"
            style={{ fontSize: 'clamp(4rem, 17vw, 15rem)', letterSpacing: '-0.05em' }}
          >
            UN
          </div>
        </div>

        {/* chapters stack — vertical numbers, active one emphasized */}
        <div
          className="relative flex flex-col items-center justify-center w-full h-full"
          style={{ opacity: clamp((local - 0.08) / 0.06) }}
        >
          {CHAPTERS.map((ch, i) => {
            const cStart = 0.1 + i * chapterSpan;
            const cLocal = clamp((local - cStart) / chapterSpan);
            const isActive = cLocal > 0.05 && cLocal < 0.95;
            const wasActive = local > cStart + chapterSpan;

            // number slides left/up as text emerges from it
            const numShiftX = isActive ? -18 : 0;
            const numOpacity = 0.16 + (isActive ? 0.84 : 0) - (wasActive ? 0.7 : 0);
            const textClip = isActive ? mapRange(cLocal, 0.05, 0.5, 0, 100) : 0;
            const textX = isActive ? mapRange(cLocal, 0.05, 0.5, 40, 0) : 40;
            const textOpacity = isActive ? mapRange(cLocal, 0.05, 0.4, 0, 1) : 0;

            return (
              <div
                key={ch.num}
                className="relative flex items-center"
                style={{ height: '22vh' }}
              >
                {/* the big number */}
                <div
                  className="chapter-num relative"
                  style={{
                    transform: `translate3d(${numShiftX}vw, 0, 0)`,
                    opacity: Math.max(0.08, numOpacity),
                    color: isActive ? 'var(--color-graphite-900)' : 'var(--color-graphite-300)',
                    transition: 'color 0.4s',
                  }}
                >
                  {ch.num}
                </div>

                {/* text emerging from the number's space */}
                <div
                  className="absolute left-[2vw] md:left-[4vw] top-1/2 -translate-y-1/2 max-w-[60vw] md:max-w-[40vw]"
                  style={{
                    clipPath: `inset(0 ${100 - textClip}% 0 0)`,
                    opacity: textOpacity,
                    transform: `translate3d(${textX}vw, 0, 0)`,
                  }}
                >
                  <div className="micro mb-3">{t.chapters.chapter} {ch.num}</div>
                  <div
                    className="chapter-text text-graphite-900"
                    style={{ fontSize: 'clamp(1.4rem, 3.4vw, 2.8rem)', lineHeight: 1 }}
                  >
                    {ch.title}
                  </div>
                  <div
                    className="mt-4 font-editorial text-graphite-500 max-w-md"
                    style={{ fontSize: 'clamp(0.85rem, 1.1vw, 1rem)', lineHeight: 1.6 }}
                  >
                    {ch.body}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* footer mark */}
        <div
          className="absolute bottom-[8%] left-1/2 -translate-x-1/2 micro"
          style={{ opacity: clamp((local - 0.9) / 0.1) }}
        >
          {t.chapters.endMark}
        </div>
      </div>
    </section>
  );
}
