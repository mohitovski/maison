import { useEffect, useState } from 'react';
import { useLang } from '@/i18n/LanguageContext';

export function Frame({ progress }: { progress: number }) {
  const { t } = useLang();
  const [time, setTime] = useState('');
  useEffect(() => {
    const tick = () => {
      const d = new Date();
      setTime(d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const sceneLabel = `${t.frame.scene} ${String(Math.min(11, Math.floor(progress * 11) + 1)).padStart(2, '0')}`;
  const pct = Math.round(progress * 100);

  return (
    <>
      <div className="fixed top-0 left-0 right-0 z-50 px-5 md:px-8 pt-5 md:pt-7 flex items-start justify-between pointer-events-none mix-blend-difference text-white">
        <div className="font-display font-bold text-sm md:text-base tracking-[0.2em]">
          MAISON&nbsp;N°I
        </div>
        <div className="hidden md:flex flex-col items-end gap-1 font-mono text-[0.6rem] tracking-[0.25em] uppercase opacity-80">
          <span>{t.frame.volume}</span>
          <span>{t.frame.editorial}</span>
        </div>
      </div>

      {/* Scene/time readout — desktop only. On mobile this sat at the
          same bottom-5 height as the floating nav pill and the language
          switcher and visually collided with both, so it's now shown
          only above the md breakpoint, where there's room for it. */}
      <div className="hidden md:flex fixed bottom-0 left-0 right-0 z-50 px-8 pb-7 items-end justify-between pointer-events-none mix-blend-difference text-white">
        <div className="font-mono text-[0.6rem] tracking-[0.25em] uppercase opacity-80">
          {sceneLabel} — {pct.toString().padStart(3, '0')}%
        </div>
        <div className="font-mono text-[0.6rem] tracking-[0.25em] uppercase opacity-80">
          {time} · {t.frame.scroll}
        </div>
      </div>

      {/* progress rail — desktop only, mirrors the readout above */}
      <div className="hidden md:block fixed right-8 top-1/2 -translate-y-1/2 z-50 h-[40vh] w-px bg-white/15 pointer-events-none mix-blend-difference">
        <div
          className="absolute top-0 left-0 w-px bg-white"
          style={{ height: `${progress * 100}%` }}
        />
      </div>

      {/* mobile equivalent: a slim top progress bar instead of the
          bottom readout, so scroll position is still visible without
          competing with the nav pill / language switcher below */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 h-[2px] bg-white/15 pointer-events-none mix-blend-difference">
        <div
          className="h-full bg-white"
          style={{ width: `${progress * 100}%` }}
        />
      </div>
    </>
  );
}
