import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

// Wraps route content with a blur/shift transition on route change.
export function PageTransition({ children }: { children: React.ReactNode }) {
  const { pathname } = useLocation();
  const [displayChildren, setDisplayChildren] = useState<React.ReactNode>(children);
  const [phase, setPhase] = useState<'idle' | 'out' | 'in'>('idle');
  const [currentPath, setCurrentPath] = useState(pathname);

  useEffect(() => {
    if (pathname === currentPath) return;
    setCurrentPath(pathname);
    setPhase('out');
    const t1 = setTimeout(() => {
      setDisplayChildren(children);
      setPhase('in');
      const t2 = setTimeout(() => setPhase('idle'), 900);
      return () => clearTimeout(t2);
    }, 500);
    return () => clearTimeout(t1);
  }, [pathname, currentPath, children]);

  const style: React.CSSProperties =
    phase === 'out'
      ? { filter: 'blur(20px)', transform: 'translate3d(0, 30px, 0)', opacity: 0 }
      : phase === 'in'
        ? { filter: 'blur(0px)', transform: 'translate3d(0, 0, 0)', opacity: 1 }
        : { filter: 'none', transform: 'none', opacity: 1 };

  return (
    <div
      style={{
        ...style,
        transition:
          phase === 'out'
            ? 'filter 0.5s ease-in, transform 0.5s ease-in, opacity 0.5s ease-in'
            : phase === 'in'
              ? 'filter 0.9s cubic-bezier(0.22,1,0.36,1), transform 0.9s cubic-bezier(0.22,1,0.36,1), opacity 0.9s cubic-bezier(0.22,1,0.36,1)'
              : 'none',
      }}
    >
      {displayChildren}
    </div>
  );
}
