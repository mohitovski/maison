import { useEffect, useRef } from 'react';

export function useCursor() {
  const raf = useRef(0);
  const target = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const current = useRef({ x: target.current.x, y: target.current.y });
  const last = useRef({ ...current.current, t: performance.now() });

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;
    };
    window.addEventListener('pointermove', onMove, { passive: true });

    const tick = () => {
      const c = current.current;
      const t = target.current;
      c.x += (t.x - c.x) * 0.16;
      c.y += (t.y - c.y) * 0.16;

      const now = performance.now();
      const dt = Math.max(1, now - last.current.t);
      const vx = (c.x - last.current.x) / dt * 16;
      const vy = (c.y - last.current.y) / dt * 16;

      const root = document.documentElement;
      root.style.setProperty('--cursor-x', `${c.x}px`);
      root.style.setProperty('--cursor-y', `${c.y}px`);
      root.style.setProperty('--cursor-vx', String(vx));
      root.style.setProperty('--cursor-vy', String(vy));

      last.current = { x: c.x, y: c.y, t: now };
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener('pointermove', onMove);
      cancelAnimationFrame(raf.current);
    };
  }, []);
}
