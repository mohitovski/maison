import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import './index.css';
import App from './App';

// HashRouter (URLs like /#/gallery) instead of BrowserRouter: GitHub Pages
// serves static files with no server-side rewrites, so a real path like
// /gallery would 404 on refresh or direct link. Hash-based routing avoids
// that entirely and needs zero server configuration.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <HashRouter>
      <App />
    </HashRouter>
  </StrictMode>
);
