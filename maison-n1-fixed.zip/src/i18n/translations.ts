export type Lang = 'ru' | 'en';

export const LANGUAGES: Lang[] = ['ru', 'en'];

export type TranslationDict = {
  nav: { home: string; gallery: string };
  frame: { scene: string; scroll: string; volume: string; editorial: string };
  entrance: {
    volume: string;
    coords: string;
    study: string;
    eauDeParfum: string;
    titleTop: string;
    titleBottom: string;
    subtitle: string;
    scrollCue: string;
    words: string[];
  };
  darkness: {
    chapter: string;
    title: string;
    titleItalic: string;
    move: string;
  };
  bottle: {
    label: string;
    volume: string;
    subLabel: string;
    textTop: string;
    textMiddle: string;
    textBottom: string;
  };
  chapters: {
    chapter: string;
    endMark: string;
    items: { num: string; title: string; body: string }[];
  };
  composition: {
    label: string;
    micro: string;
    notes: string[];
  };
  sketch: {
    microLeft: string;
    microRight: string;
    annotations: { label: string; value: string }[];
  };
  price: {
    label: string;
    value: string;
    note: string;
  };
  notes: {
    groups: { label: string; micro: string; notes: string[] }[];
    footer: string;
  };
  heart: {
    micro: string;
    caption: string;
  };
  reviews: {
    micro: string;
    title: string;
    items: { author: string; role: string; text: string }[];
  };
  gallery: {
    archive: string;
    volume: string;
    comingSoon: string;
    collection: string;
    collectionDescription: string;
    view: string;
    close: string;
    colors: string[];
    price: string;
    priceNote: string;
  };
  languageSwitcher: { ru: string; en: string };
};

const ru: TranslationDict = {
  nav: { home: 'ГЛАВНАЯ', gallery: 'ГАЛЕРЕЯ' },
  frame: { scene: 'СЦЕНА', scroll: 'СКРОЛЛ', volume: 'Eau de Parfum / Том 01', editorial: 'Эдиторал — Исследование тени' },
  entrance: {
    volume: 'Maison N°I — Том 01',
    coords: 'N 48.8566 / E 2.3522',
    study: 'Исследование тени',
    eauDeParfum: '— Eau de Parfum —',
    titleTop: 'ЧТО-ТО',
    titleBottom: 'оставшееся в воздухе',
    subtitle: 'Парфюм, который не заявляет о себе. Он остаётся в комнате после вашего ухода, в складке воротника, в тихий час перед рассветом.',
    scrollCue: 'СКРОЛЛ ДЛЯ ВХОДА',
    words: ['тень', 'дым', 'тишина', 'темнота', 'след', 'кожа', 'ночь'],
  },
  darkness: {
    chapter: '— Глава II —',
    title: 'что остаётся',
    titleItalic: 'когда свет уходит',
    move: 'двигай, чтобы исследовать',
  },
  bottle: {
    label: 'N°I — Eau de Parfum',
    volume: '100 МЛ / 3.4 FL OZ',
    subLabel: '— объект, уменьшенный —',
    textTop: 'MAISON',
    textMiddle: 'номер',
    textBottom: 'UN',
  },
  chapters: {
    chapter: 'Глава',
    endMark: '— конец первого тома —',
    items: [
      { num: '01', title: 'ПЕРВЫЙ СЛЕД', body: 'Всё начинается без звука. Одна линия, проведённая по коже, по памяти. Первая нота не спрашивает — она оседает.' },
      { num: '02', title: 'ТЕМНОТА', body: 'Затем комната темнеет. То, что было ярким, становится атмосферой. Аромат живёт там, где заканчивается зрение — в пространстве между дыханием и мыслью.' },
      { num: '03', title: 'КОЖА', body: 'Тепло находит поверхность. Кедр, ирис, шёпот кожи. Он не лежит на коже — он становится кожей, медленно, на часы.' },
      { num: '04', title: 'ПАМЯТЬ', body: 'Задолго после вашего ухода комната сохраняет форму вас. Пальто на стуле. Перевёрнутая подушка. След, который переживает момент.' },
    ],
  },
  composition: {
    label: '— композиция —',
    micro: 'N°I — Ольфакторная пирамида',
    notes: ['ИРИС', 'ВАНИЛЬ', 'МУСКУС', 'КЕДР'],
  },
  sketch: {
    microLeft: 'N°I — Технический лист',
    microRight: 'Рисованное исследование / 01',
    annotations: [
      { label: 'РАДИУС АРОМАТА', value: '1.2 М' },
      { label: 'ФИРМЕННАЯ НОТА', value: '01' },
      { label: 'СТОЙКОСТЬ', value: '12 Ч' },
      { label: 'ШЛЕЙФ', value: '360°' },
      { label: 'КОНЦЕНТРАЦИЯ', value: '24%' },
      { label: 'ОБЪЁМ', value: '100 МЛ' },
    ],
  },
  notes: {
    groups: [
      { label: 'ВЕРХНИЕ НОТЫ', micro: 'I — Открытие', notes: ['Бергамот', 'Розовый перец', 'Ирис'] },
      { label: 'НОТЫ СЕРДЦА', micro: 'II — Сердцевина', notes: ['Фиалка', 'Роза', 'Жасмин'] },
      { label: 'БАЗОВЫЕ НОТЫ', micro: 'III — След', notes: ['Мускус', 'Кедр', 'Янтарь'] },
    ],
    footer: '— финал —',
  },
  price: {
    label: 'ЦЕНА',
    value: '€ 128',
    note: '100 мл',
  },
  heart: {
    micro: '— то, что остаётся —',
    caption: 'сердце аромата',
  },
  reviews: {
    micro: '— Впечатления —',
    title: 'ОТЗЫВЫ',
    items: [
      { author: 'Анна К.', role: 'Парфюмерный критик', text: 'Аромат, который не пытается понравиться. Он просто существует — и в этом его сила. Стойкость поражает.' },
      { author: 'Михаил В.', role: 'Коллекционер', text: 'Минимализм, доведённый до совершенства. Кедр и ирис сплетаются так тонко, что граница исчезает.' },
      { author: 'Елена Д.', role: 'Стилист', text: 'Носишь его как вторую кожу. Он не кричит, он шепчет. И этот шёпот слышен даже на следующий день.' },
    ],
  },
  gallery: {
    archive: 'MAISON',
    volume: '— Архив / Том I —',
    comingSoon: 'листайте вниз',
    collection: 'КОЛЛЕКЦИЯ #1',
    collectionDescription: 'N°I — пять состояний одного аромата',
    view: 'открыть изображение',
    close: 'закрыть',
    colors: ['МЯТА', 'БЕЛЫЙ', 'ЧЁРНЫЙ', 'ИЗУМРУД', 'ТУМАН'],
    price: '€ 128',
    priceNote: '100 мл',
  },
  languageSwitcher: { ru: 'RUS', en: 'ENG' },
};

const en: TranslationDict = {
  nav: { home: 'HOME', gallery: 'GALLERY' },
  frame: { scene: 'SCENE', scroll: 'SCROLL', volume: 'Eau de Parfum / Vol. 01', editorial: 'Editorial — A study in shadow' },
  entrance: {
    volume: 'Maison N°I — Vol. 01',
    coords: 'N 48.8566 / E 2.3522',
    study: 'A study in shadow',
    eauDeParfum: '— Eau de Parfum —',
    titleTop: 'SOMETHING',
    titleBottom: 'left in the air',
    subtitle: 'A perfume that does not announce itself. It lingers in the room after you leave, in the fold of a collar, in the quiet hour before dawn.',
    scrollCue: 'SCROLL TO ENTER',
    words: ['shadow', 'smoke', 'silence', 'darkness', 'trace', 'skin', 'night'],
  },
  darkness: {
    chapter: '— Chapter II —',
    title: 'what remains',
    titleItalic: 'when the light leaves',
    move: 'move to explore',
  },
  bottle: {
    label: 'N°I — Eau de Parfum',
    volume: '100 ML / 3.4 FL OZ',
    subLabel: '— the object, diminished —',
    textTop: 'MAISON',
    textMiddle: 'numéro',
    textBottom: 'UN',
  },
  chapters: {
    chapter: 'Chapter',
    endMark: '— end of volume one —',
    items: [
      { num: '01', title: 'THE FIRST TRACE', body: 'It begins without sound. A single line drawn across skin, across memory. The first note does not ask — it settles.' },
      { num: '02', title: 'THE DARKNESS', body: 'Then the room dims. What was bright becomes atmosphere. The fragrance lives where sight ends, in the space between breath and thought.' },
      { num: '03', title: 'THE SKIN', body: 'Warmth finds a surface. Cedar, iris, a whisper of leather. It does not sit on the skin — it becomes the skin, slowly, for hours.' },
      { num: '04', title: 'THE MEMORY', body: 'Long after you have gone, the room holds a shape of you. A coat on a chair. A pillow turned. The trace that outlives the moment.' },
    ],
  },
  composition: {
    label: '— the composition —',
    micro: 'N°I — Olfactory pyramid',
    notes: ['IRIS', 'VANILLA', 'MUSK', 'CEDAR'],
  },
  sketch: {
    microLeft: 'N°I — Technical sheet',
    microRight: 'Drawn study / 01',
    annotations: [
      { label: 'RADIUS OF SCENT', value: '1.2 M' },
      { label: 'SIGNATURE NOTE', value: '01' },
      { label: 'LONGEVITY', value: '12 H' },
      { label: 'SCENT TRAIL', value: '360°' },
      { label: 'CONCENTRATION', value: '24%' },
      { label: 'VOLUME', value: '100 ML' },
    ],
  },
  notes: {
    groups: [
      { label: 'TOP NOTES', micro: 'I — The opening', notes: ['Bergamot', 'Pink Pepper', 'Iris'] },
      { label: 'HEART NOTES', micro: 'II — The core', notes: ['Violet', 'Rose', 'Jasmine'] },
      { label: 'BASE NOTES', micro: 'III — The trace', notes: ['Musk', 'Cedar', 'Amber'] },
    ],
    footer: '— fin —',
  },
  price: {
    label: 'PRICE',
    value: '€ 128',
    note: '100 ml',
  },
  heart: {
    micro: '— what remains —',
    caption: 'the heart of the scent',
  },
  reviews: {
    micro: '— Impressions —',
    title: 'REVIEWS',
    items: [
      { author: 'Anna K.', role: 'Fragrance critic', text: 'A scent that does not try to please. It simply exists — and that is its power. The longevity is remarkable.' },
      { author: 'Mikhail V.', role: 'Collector', text: 'Minimalism taken to perfection. Cedar and iris intertwine so finely that the boundary disappears.' },
      { author: 'Elena D.', role: 'Stylist', text: 'You wear it like a second skin. It does not shout, it whispers. And that whisper is heard even the next day.' },
    ],
  },
  gallery: {
    archive: 'MAISON',
    volume: '— Archive / Volume I —',
    comingSoon: 'scroll down',
    collection: 'COLLECTION #1',
    collectionDescription: 'N°I — five states of one fragrance',
    view: 'open image',
    close: 'close',
    colors: ['MINT', 'WHITE', 'BLACK', 'EMERALD', 'MIST'],
    price: '€ 128',
    priceNote: '100 ml',
  },
  languageSwitcher: { ru: 'RUS', en: 'ENG' },
};

export const translations: Record<Lang, TranslationDict> = { ru, en };
