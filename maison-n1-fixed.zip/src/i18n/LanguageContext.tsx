import { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { type Lang, translations, type TranslationDict } from './translations';

type LanguageContextValue = {
  lang: Lang;
  t: TranslationDict;
  setLang: (l: Lang) => void;
  toggleLang: () => void;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);
const STORAGE_KEY = 'maison-lang';

const DOC_TITLES: Record<Lang, { title: string; description: string }> = {
  ru: {
    title: 'MAISON N°I — Исследование тени',
    description: 'Эдиториал-кампания парфюма. Скролльте, чтобы войти.',
  },
  en: {
    title: 'MAISON N°I — A study in shadow',
    description: 'An editorial perfume campaign. Scroll to enter.',
  },
};

function getInitialLang(): Lang {
  if (typeof window === 'undefined') return 'ru';
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === 'ru' || stored === 'en') return stored;
  // fall back to the browser's language if nothing was saved yet
  return window.navigator.language?.toLowerCase().startsWith('ru') ? 'ru' : 'en';
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(getInitialLang);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    window.localStorage.setItem(STORAGE_KEY, l);
  }, []);
  const toggleLang = useCallback(() => {
    setLangState((p) => {
      const next = p === 'ru' ? 'en' : 'ru';
      window.localStorage.setItem(STORAGE_KEY, next);
      return next;
    });
  }, []);

  // Keep <html lang>, the document title and the meta description in
  // sync with the active language for a11y, SEO and social sharing.
  useEffect(() => {
    document.documentElement.lang = lang;
    document.title = DOC_TITLES[lang].title;
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) metaDescription.setAttribute('content', DOC_TITLES[lang].description);
  }, [lang]);

  return (
    <LanguageContext.Provider value={{ lang, t: translations[lang], setLang, toggleLang }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLang must be used within LanguageProvider');
  return ctx;
}
