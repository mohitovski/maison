import { Routes, Route, useLocation } from 'react-router-dom';
import { Nav } from '@/components/Nav';
import { PageTransition } from '@/components/PageTransition';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { LanguageProvider } from '@/i18n/LanguageContext';
import { useCursor } from '@/hooks/useCursor';
import { Home } from '@/pages/Home';
import { Gallery } from '@/pages/Gallery';

function App() {
  const location = useLocation();
  useCursor();

  return (
    <LanguageProvider>
      <Nav />
      <LanguageSwitcher />
      <div className="ghost-cursor" aria-hidden />
      <PageTransition key={location.pathname}>
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/gallery" element={<Gallery />} />
        </Routes>
      </PageTransition>
    </LanguageProvider>
  );
}

export default App;
