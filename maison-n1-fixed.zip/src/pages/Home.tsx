import { useScrollProgress } from '@/hooks/useScrollProgress';
import { Frame } from '@/components/Frame';
import { SceneEntrance } from '@/components/scenes/SceneEntrance';
import { SceneDarkness } from '@/components/scenes/SceneDarkness';
import { SceneBottle } from '@/components/scenes/SceneBottle';
import { SceneChapters } from '@/components/scenes/SceneChapters';
import { SceneComposition } from '@/components/scenes/SceneComposition';
import { SceneSketch } from '@/components/scenes/SceneSketch';
import { SceneNotes } from '@/components/scenes/SceneNotes';
import { SceneHeart } from '@/components/scenes/SceneHeart';
import { SceneReviews } from '@/components/scenes/SceneReviews';

// Scroll progress allocation per scene (must sum to 1)
const SCENE_RANGES = [
  { start: 0.0, end: 0.10 }, // 1 — entrance
  { start: 0.10, end: 0.20 }, // 2 — darkness
  { start: 0.20, end: 0.38 }, // 3+4 — bottle morph + recede
  { start: 0.38, end: 0.50 }, // 5+6 — slide transition + chapters
  { start: 0.50, end: 0.60 }, // 7 — composition orbit
  { start: 0.60, end: 0.72 }, // 8 — bottle + pencil sketch
  { start: 0.72, end: 0.82 }, // 9 — full notes
  { start: 0.82, end: 0.91 }, // 10 — heart draw + fill
  { start: 0.91, end: 1.0 }, // 11 — reviews
];

export function Home() {
  const progress = useScrollProgress();

  return (
    <>
      <Frame progress={progress} />

      {/* fixed stage */}
      <div className="fixed inset-0 z-10">
        <SceneEntrance progress={progress} start={SCENE_RANGES[0].start} end={SCENE_RANGES[0].end} />
        <SceneDarkness progress={progress} start={SCENE_RANGES[1].start} end={SCENE_RANGES[1].end} />
        <SceneBottle progress={progress} start={SCENE_RANGES[2].start} end={SCENE_RANGES[2].end} />
        <SceneChapters progress={progress} start={SCENE_RANGES[3].start} end={SCENE_RANGES[3].end} />
        <SceneComposition progress={progress} start={SCENE_RANGES[4].start} end={SCENE_RANGES[4].end} />
        <SceneSketch progress={progress} start={SCENE_RANGES[5].start} end={SCENE_RANGES[5].end} />
        <SceneNotes progress={progress} start={SCENE_RANGES[6].start} end={SCENE_RANGES[6].end} />
        <SceneHeart progress={progress} start={SCENE_RANGES[7].start} end={SCENE_RANGES[7].end} />
        <SceneReviews progress={progress} start={SCENE_RANGES[8].start} end={SCENE_RANGES[8].end} />
      </div>

      {/* scroll spacer — creates the scrollable height */}
      <div aria-hidden style={{ height: '1100vh' }} />
    </>
  );
}
