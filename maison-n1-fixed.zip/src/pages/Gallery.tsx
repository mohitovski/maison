import { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

// Vite's public assets are served relative to `base` (see vite.config.ts).
// Using import.meta.env.BASE_URL instead of a hardcoded "/images/..." keeps
// these correct whether the site is hosted at a domain root or in a GitHub
// Pages project subpath (username.github.io/repo-name/).
const IMG_BASE = import.meta.env.BASE_URL + 'images/';
const images = [
  `${IMG_BASE}maison-mint.jpg`,
  `${IMG_BASE}maison-white.jpg`,
  `${IMG_BASE}maison-black.jpg`,
  `${IMG_BASE}maison-green.jpg`,
  `${IMG_BASE}maison-blue.jpg`,
];

const cardStyles = [
  { width: 'clamp(12rem, 20vw, 19rem)', marginTop: '6vh', rotate: '-5deg' },
  { width: 'clamp(14rem, 23vw, 22rem)', marginTop: '16vh', rotate: '3deg' },
  { width: 'clamp(11rem, 17vw, 16rem)', marginTop: '1vh', rotate: '-2deg' },
  { width: 'clamp(15rem, 25vw, 24rem)', marginTop: '11vh', rotate: '6deg' },
  { width: 'clamp(12rem, 19vw, 18rem)', marginTop: '4vh', rotate: '-4deg' },
];

export function Gallery() {
  const { t } = useLang();
  const scrollRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [activeImage, setActiveImage] = useState<string | null>(null);

  useEffect(() => {
    const scrollNode = scrollRef.current;
    if (!scrollNode) return;

    const updateProgress = () => {
      const heroHeight = heroRef.current?.offsetHeight ?? scrollNode.clientHeight;
      setProgress(Math.min(1, scrollNode.scrollTop / Math.max(1, heroHeight - scrollNode.clientHeight)));
    };

    scrollNode.addEventListener('scroll', updateProgress, { passive: true });
    updateProgress();
    return () => scrollNode.removeEventListener('scroll', updateProgress);
  }, []);

  useEffect(() => {
    if (!activeImage) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setActiveImage(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeImage]);

  return (
    <div ref={scrollRef} className="fixed inset-0 z-10 overflow-y-auto no-scrollbar bg-[#f8f8f6] text-graphite-900">
      <section ref={heroRef} className="relative h-[150vh] min-h-[760px] bg-[#f8f8f6]">
        <div className="sticky top-0 h-screen min-h-[620px] overflow-hidden">
          <div className="absolute inset-0 opacity-[0.06] pointer-events-none gallery-grid" />
          <div
            className="absolute inset-x-0 top-0 h-[115%] bg-[#606166] ink-fill"
            style={{ transform: `scaleY(${progress})`, opacity: 0.96 }}
          />
          <div className="ink-pool" style={{ top: `${Math.max(0, progress * 93)}%`, opacity: progress > 0.03 ? 1 : 0 }} />
          <div className="ink-drop ink-drop--one" style={{ top: `${progress * 44}%`, opacity: progress > 0.08 ? 1 : 0 }} />
          <div className="ink-drop ink-drop--two" style={{ top: `${progress * 62}%`, opacity: progress > 0.2 ? 1 : 0 }} />

          <div className="absolute top-[14%] left-[8%] micro" style={{ color: progress > 0.55 ? '#d1d1d4' : '#82828a' }}>
            {t.gallery.volume}
          </div>
          <div className="absolute top-[14%] right-[8%] micro text-right" style={{ color: progress > 0.55 ? '#d1d1d4' : '#82828a' }}>
            01 / 05
          </div>

          <div
            className="absolute left-1/2 top-1/2 z-10 text-center whitespace-nowrap"
            style={{
              color: progress > 0.6 ? '#f8f8f6' : '#0e0e10',
              opacity: 1 - Math.max(0, progress - 0.68) * 2.5,
              transform: `translate(-50%, calc(-50% - ${progress * 43}vh)) scale(${1 - progress * 0.42})`,
              transformOrigin: 'center center',
              transition: 'color 0.5s ease',
            }}
          >
            <div className="micro mb-6" style={{ color: 'currentColor' }}>{t.gallery.volume}</div>
            <h1 className="font-display font-bold tracking-[-0.07em] leading-[0.78]" style={{ fontSize: 'clamp(5rem, 19vw, 18rem)' }}>
              {t.gallery.archive}
            </h1>
            <p className="mt-9 font-editorial italic text-[clamp(1rem,1.6vw,1.35rem)]" style={{ color: 'currentColor', opacity: 0.65 }}>
              {t.gallery.comingSoon}
            </p>
          </div>

          <div className="absolute bottom-[9%] left-1/2 -translate-x-1/2 micro flex items-center gap-3" style={{ color: progress > 0.55 ? '#d1d1d4' : '#82828a', opacity: 1 - progress * 0.8 }}>
            <span className="block h-px w-8 bg-current" /> SCROLL <span className="block h-px w-8 bg-current" />
          </div>
        </div>
      </section>

      <section className="relative min-h-screen overflow-hidden px-[6%] py-24 md:px-[8%] md:py-36">
        <div className="mx-auto max-w-[1500px]">
          <div className="flex items-end justify-between gap-8 border-b border-graphite-300 pb-7">
            <div>
              <div className="micro mb-4">— Maison N°I —</div>
              <h2 className="font-display text-[clamp(2.5rem,7vw,7rem)] font-bold leading-[0.85] tracking-[-0.06em]">{t.gallery.collection}</h2>
            </div>
            <p className="hidden max-w-[13rem] pb-1 text-right font-editorial text-sm leading-6 text-graphite-500 md:block">{t.gallery.collectionDescription}</p>
          </div>

          <div className="flex flex-wrap items-start justify-center gap-x-[4vw] gap-y-10 py-12 sm:gap-y-16 sm:py-20 md:justify-between md:gap-y-8">
            {images.map((image, index) => {
              const style = cardStyles[index];
              const colorName = t.gallery.colors[index];
              return (
                <button
                  key={image}
                  type="button"
                  className="gallery-card group relative shrink-0 text-left"
                  style={{ width: style.width, marginTop: style.marginTop, transform: `rotate(${style.rotate})` }}
                  onClick={() => setActiveImage(image)}
                  aria-label={`${t.gallery.view} — ${colorName}`}
                >
                  <span className="gallery-card__glow" />
                  <img
                    src={image}
                    alt={`Maison N°I — ${colorName}`}
                    loading="lazy"
                    decoding="async"
                    className="relative z-[1] aspect-square w-full object-cover transition duration-700 group-hover:scale-[1.02]"
                  />
                  <span className="relative z-[1] mt-3 flex items-center justify-between font-mono text-[0.55rem] tracking-[0.2em] text-graphite-500">
                    <span>MAISON / {colorName}</span>
                    <span className="opacity-0 transition-opacity group-hover:opacity-100">↗</span>
                  </span>
                  <span className="relative z-[1] mt-1 flex items-center justify-between font-mono text-[0.55rem] tracking-[0.15em] text-graphite-400">
                    <span>{t.gallery.price}</span>
                    <span>{t.gallery.priceNote}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {activeImage && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#0e0e10]/95 p-6 md:p-12" onClick={() => setActiveImage(null)} role="dialog" aria-modal="true">
          <button
            type="button"
            onClick={() => setActiveImage(null)}
            className="absolute right-6 flex items-center gap-2 font-mono text-[0.6rem] tracking-[0.2em] text-white/70 transition hover:text-white"
            style={{ top: 'calc(1.5rem + env(safe-area-inset-top))' }}
          >
            {t.gallery.close} <X size={16} strokeWidth={1} />
          </button>
          <img
            src={activeImage}
            alt={`Maison N°I — ${t.gallery.colors[images.indexOf(activeImage)] ?? ''}`}
            className="max-h-full max-w-full object-contain"
            onClick={(event) => event.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
